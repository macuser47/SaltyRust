package android.app;

public interface Application$OnProvideAssistDataListener {
}
