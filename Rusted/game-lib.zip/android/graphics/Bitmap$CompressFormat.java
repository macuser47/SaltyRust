package android.graphics;

public enum Bitmap$CompressFormat {
   // $FF: renamed from: a android.graphics.Bitmap$CompressFormat
   field_3274(0),
   // $FF: renamed from: b android.graphics.Bitmap$CompressFormat
   field_3275(1),
   // $FF: renamed from: c android.graphics.Bitmap$CompressFormat
   field_3276(2);

   // $FF: renamed from: d int
   final int field_3277;

   private Bitmap$CompressFormat(int var3) {
      this.field_3277 = var3;
   }
}
