package android.graphics;

public enum Canvas$EdgeType {
   // $FF: renamed from: a android.graphics.Canvas$EdgeType
   field_3989(0),
   // $FF: renamed from: b android.graphics.Canvas$EdgeType
   field_3990(1);

   // $FF: renamed from: c int
   public final int field_3991;

   private Canvas$EdgeType(int var3) {
      this.field_3991 = var3;
   }
}
