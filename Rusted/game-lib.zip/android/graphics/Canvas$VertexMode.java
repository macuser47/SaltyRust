package android.graphics;

public enum Canvas$VertexMode {
   // $FF: renamed from: a android.graphics.Canvas$VertexMode
   field_4737(0),
   // $FF: renamed from: b android.graphics.Canvas$VertexMode
   field_4738(1),
   // $FF: renamed from: c android.graphics.Canvas$VertexMode
   field_4739(2);

   // $FF: renamed from: d int
   public final int field_4740;

   private Canvas$VertexMode(int var3) {
      this.field_4740 = var3;
   }
}
