package android.graphics;

import android.graphics.PorterDuff.Mode;
import android.graphics.Region.Op;

public class Canvas {
   // $FF: renamed from: a (android.graphics.Bitmap) void
   public void method_3082(Bitmap var1) {
   }

   // $FF: renamed from: a () int
   public int method_3083() {
      return 0;
   }

   // $FF: renamed from: b () void
   public void method_3084() {
   }

   // $FF: renamed from: a (float, float) void
   public void method_3085(float var1, float var2) {
   }

   // $FF: renamed from: b (float, float) void
   public void method_3086(float var1, float var2) {
   }

   // $FF: renamed from: a (float, float, float, float) void
   public void method_3087(float var1, float var2, float var3, float var4) {
   }

   // $FF: renamed from: a (float, float, float) void
   public void method_3088(float var1, float var2, float var3) {
   }

   // $FF: renamed from: a (android.graphics.RectF, android.graphics.Region.Op) boolean
   public boolean method_3089(RectF var1, Op var2) {
      return false;
   }

   // $FF: renamed from: a (android.graphics.Rect, android.graphics.Region.Op) boolean
   public boolean method_3090(Rect var1, Op var2) {
      return false;
   }

   // $FF: renamed from: a (int) void
   public void method_3091(int var1) {
   }

   // $FF: renamed from: a (int, android.graphics.PorterDuff.Mode) void
   public void method_3092(int var1, Mode var2) {
   }

   // $FF: renamed from: a (float[], int, int, android.graphics.Paint) void
   public void method_3093(float[] var1, int var2, int var3, Paint var4) {
   }

   // $FF: renamed from: a (float, float, float, float, android.graphics.Paint) void
   public void method_3094(float var1, float var2, float var3, float var4, Paint var5) {
   }

   // $FF: renamed from: a (android.graphics.RectF, android.graphics.Paint) void
   public void method_3095(RectF var1, Paint var2) {
   }

   // $FF: renamed from: a (android.graphics.Rect, android.graphics.Paint) void
   public void method_3096(Rect var1, Paint var2) {
   }

   // $FF: renamed from: a (float, float, float, android.graphics.Paint) void
   public void method_3097(float var1, float var2, float var3, Paint var4) {
   }

   // $FF: renamed from: a (android.graphics.Bitmap, float, float, android.graphics.Paint) void
   public void method_3098(Bitmap var1, float var2, float var3, Paint var4) {
   }

   // $FF: renamed from: a (android.graphics.Bitmap, android.graphics.Rect, android.graphics.RectF, android.graphics.Paint) void
   public void method_3099(Bitmap var1, Rect var2, RectF var3, Paint var4) {
   }

   // $FF: renamed from: a (android.graphics.Bitmap, android.graphics.Matrix, android.graphics.Paint) void
   public void method_3100(Bitmap var1, Matrix var2, Paint var3) {
   }

   // $FF: renamed from: a (java.lang.String, float, float, android.graphics.Paint) void
   public void method_3101(String var1, float var2, float var3, Paint var4) {
   }
}
