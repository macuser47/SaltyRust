package android.graphics;

public class ColorFilter {
}
