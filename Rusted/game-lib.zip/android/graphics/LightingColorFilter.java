package android.graphics;

public class LightingColorFilter extends ColorFilter {
   // $FF: renamed from: a int
   public int field_3994;
   // $FF: renamed from: b int
   public int field_3995;

   public LightingColorFilter(int var1, int var2) {
      this.field_3994 = var1;
      this.field_3995 = var2;
   }
}
