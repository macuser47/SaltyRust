package android.graphics;

public enum Matrix$ScaleToFit {
   // $FF: renamed from: a android.graphics.Matrix$ScaleToFit
   field_4089(0),
   // $FF: renamed from: b android.graphics.Matrix$ScaleToFit
   field_4090(1),
   // $FF: renamed from: c android.graphics.Matrix$ScaleToFit
   field_4091(2),
   // $FF: renamed from: d android.graphics.Matrix$ScaleToFit
   field_4092(3);

   // $FF: renamed from: e int
   final int field_4093;

   private Matrix$ScaleToFit(int var3) {
      this.field_4093 = var3;
   }
}
