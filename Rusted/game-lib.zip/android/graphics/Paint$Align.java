package android.graphics;

public enum Paint$Align {
   // $FF: renamed from: a android.graphics.Paint$Align
   field_2226(0),
   // $FF: renamed from: b android.graphics.Paint$Align
   field_2227(1),
   // $FF: renamed from: c android.graphics.Paint$Align
   field_2228(2);

   // $FF: renamed from: d int
   final int field_2229;

   private Paint$Align(int var3) {
      this.field_2229 = var3;
   }
}
