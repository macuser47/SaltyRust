package android.graphics;

public enum Paint$Cap {
   // $FF: renamed from: a android.graphics.Paint$Cap
   field_1807(0),
   // $FF: renamed from: b android.graphics.Paint$Cap
   field_1808(1),
   // $FF: renamed from: c android.graphics.Paint$Cap
   field_1809(2);

   // $FF: renamed from: d int
   final int field_1810;

   private Paint$Cap(int var3) {
      this.field_1810 = var3;
   }
}
