package android.graphics;

public class Paint$FontMetrics {
}
