package android.graphics;

public class Paint$FontMetricsInt {
   // $FF: renamed from: a int
   public int field_3058;
   // $FF: renamed from: b int
   public int field_3059;
   // $FF: renamed from: c int
   public int field_3060;
   // $FF: renamed from: d int
   public int field_3061;
   // $FF: renamed from: e int
   public int field_3062;

   public String toString() {
      return "FontMetricsInt: top=" + this.field_3058 + " ascent=" + this.field_3059 + " descent=" + this.field_3060 + " bottom=" + this.field_3061 + " leading=" + this.field_3062;
   }
}
