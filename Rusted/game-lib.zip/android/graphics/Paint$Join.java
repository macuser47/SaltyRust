package android.graphics;

public enum Paint$Join {
   // $FF: renamed from: a android.graphics.Paint$Join
   field_4134(0),
   // $FF: renamed from: b android.graphics.Paint$Join
   field_4135(1),
   // $FF: renamed from: c android.graphics.Paint$Join
   field_4136(2);

   // $FF: renamed from: d int
   final int field_4137;

   private Paint$Join(int var3) {
      this.field_4137 = var3;
   }
}
