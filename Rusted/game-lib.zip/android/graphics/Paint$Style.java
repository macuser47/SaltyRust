package android.graphics;

public enum Paint$Style {
   // $FF: renamed from: a android.graphics.Paint$Style
   field_4585(0),
   // $FF: renamed from: b android.graphics.Paint$Style
   field_4586(1),
   // $FF: renamed from: c android.graphics.Paint$Style
   field_4587(2);

   // $FF: renamed from: d int
   final int field_4588;

   private Paint$Style(int var3) {
      this.field_4588 = var3;
   }
}
