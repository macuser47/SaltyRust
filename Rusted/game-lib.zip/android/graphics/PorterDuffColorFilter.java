package android.graphics;

import android.graphics.PorterDuff.Mode;

public class PorterDuffColorFilter extends ColorFilter {
   public PorterDuffColorFilter(int var1, Mode var2) {
   }
}
