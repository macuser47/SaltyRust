package android.graphics;

import android.graphics.PorterDuff.Mode;

public class PorterDuffXfermode extends Xfermode {
   // $FF: renamed from: a android.graphics.PorterDuff.Mode
   public final Mode field_2266;

   public PorterDuffXfermode(Mode var1) {
      this.field_2266 = var1;
   }
}
