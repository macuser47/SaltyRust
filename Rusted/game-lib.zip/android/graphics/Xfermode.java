package android.graphics;

public class Xfermode {
   protected void finalize() {
   }
}
