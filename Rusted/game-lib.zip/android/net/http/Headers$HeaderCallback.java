package android.net.http;

public interface Headers$HeaderCallback {
}
