package android.net.http;

import java.util.ArrayList;

public final class Headers {
   // $FF: renamed from: a long
   private long field_3901 = 0L;
   // $FF: renamed from: b long
   private long field_3902 = -1L;
   // $FF: renamed from: c int
   private int field_3903 = 0;
   // $FF: renamed from: d java.util.ArrayList
   private ArrayList field_3904 = new ArrayList(2);
   // $FF: renamed from: e java.lang.String[]
   private String[] field_3905 = new String[19];
   // $FF: renamed from: f java.lang.String[]
   private static final String[] field_3906 = new String[]{"transfer-encoding", "content-length", "content-type", "content-encoding", "connection", "location", "proxy-connection", "www-authenticate", "proxy-authenticate", "content-disposition", "accept-ranges", "expires", "cache-control", "last-modified", "etag", "set-cookie", "pragma", "refresh", "x-permitted-cross-domain-policies"};
   // $FF: renamed from: g java.util.ArrayList
   private ArrayList field_3907 = new ArrayList(4);
   // $FF: renamed from: h java.util.ArrayList
   private ArrayList field_3908 = new ArrayList(4);
}
