package android.os;

public interface Handler$Callback {
   // $FF: renamed from: a (android.os.Message) boolean
   boolean method_53(Message var1);
}
