package android.os;

public interface IMessenger extends IInterface {
   // $FF: renamed from: a (android.os.Message) void
   void method_52(Message var1);
}
