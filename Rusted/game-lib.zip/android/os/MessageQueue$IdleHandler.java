package android.os;

public interface MessageQueue$IdleHandler {
   // $FF: renamed from: a () boolean
   boolean method_145();
}
