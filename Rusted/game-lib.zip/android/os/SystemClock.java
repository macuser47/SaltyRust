package android.os;

public final class SystemClock {
   private SystemClock() {
   }

   // $FF: renamed from: a () long
   public static long method_3231() {
      return System.currentTimeMillis();
   }
}
