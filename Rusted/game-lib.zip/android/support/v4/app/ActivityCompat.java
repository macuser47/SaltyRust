package android.support.v4.app;

import android.app.Activity;

public class ActivityCompat {
   // $FF: renamed from: a (android.app.Activity, java.lang.String[], int) void
   public static void method_2435(Activity var0, String[] var1, int var2) {
   }
}
