package android.support.v4.content;

import android.content.Context;

public class ContextCompat {
   // $FF: renamed from: a (android.content.Context, java.lang.String) int
   public static int method_3278(Context var0, String var1) {
      throw new IllegalArgumentException("Placeholder only");
   }
}
