package android.util;

public interface Log$TerribleFailureHandler {
}
