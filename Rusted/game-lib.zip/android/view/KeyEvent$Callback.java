package android.view;

public interface KeyEvent$Callback {
}
