package android.view;

import android.util.SparseIntArray;

public class KeyEvent$DispatcherState {
   // $FF: renamed from: a android.util.SparseIntArray
   SparseIntArray field_2312 = new SparseIntArray();
}
