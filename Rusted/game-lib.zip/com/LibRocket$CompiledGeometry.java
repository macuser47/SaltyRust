package com;

public class LibRocket$CompiledGeometry {
   // $FF: renamed from: id int
   public int field_3993;
   public float[] verticesXY;
   public float[] verticesUV;
   public int[] verticesColors;
   public int[] indices;
   public int textureId;
   public Object bbox;
}
