package com;

public class LibRocket$TextureHolder {
   public int index;
   public int width;
   public int height;
   // $FF: synthetic field
   final LibRocket this$0;

   public LibRocket$TextureHolder(LibRocket var1) {
      this.this$0 = var1;
   }

   public void remove() {
   }
}
