package com.codedisaster.steamworks;

public interface SteamAPIWarningMessageHook {
   void onWarningMessage(int var1, String var2);
}
