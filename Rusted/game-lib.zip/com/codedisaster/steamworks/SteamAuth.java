package com.codedisaster.steamworks;

public class SteamAuth {
}
