package com.codedisaster.steamworks;

abstract class SteamCallbackAdapter {
   protected final Object callback;

   SteamCallbackAdapter(Object var1) {
      this.callback = var1;
   }
}
