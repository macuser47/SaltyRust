package com.codedisaster.steamworks;

public enum SteamController$LEDFlag {
   SetColor,
   RestoreUserDefault;
}
