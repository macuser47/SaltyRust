package com.codedisaster.steamworks;

public enum SteamController$Pad {
   Left,
   Right;
}
