package com.codedisaster.steamworks;

public class SteamControllerActionSetHandle extends SteamNativeHandle {
   SteamControllerActionSetHandle(long var1) {
      super(var1);
   }
}
