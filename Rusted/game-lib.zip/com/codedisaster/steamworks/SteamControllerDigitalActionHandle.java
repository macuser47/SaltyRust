package com.codedisaster.steamworks;

public class SteamControllerDigitalActionHandle extends SteamNativeHandle {
   SteamControllerDigitalActionHandle(long var1) {
      super(var1);
   }
}
