package com.codedisaster.steamworks;

public class SteamControllerHandle extends SteamNativeHandle {
   public SteamControllerHandle(long var1) {
      super(var1);
   }
}
