package com.codedisaster.steamworks;

public class SteamException extends Exception {
   public SteamException() {
   }

   public SteamException(String var1) {
      super(var1);
   }

   public SteamException(String var1, Throwable var2) {
      super(var1, var2);
   }

   public SteamException(Throwable var1) {
      super(var1);
   }
}
