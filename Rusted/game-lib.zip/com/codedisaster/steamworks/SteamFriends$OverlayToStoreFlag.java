package com.codedisaster.steamworks;

public enum SteamFriends$OverlayToStoreFlag {
   None,
   AddToCart,
   AddToCartAndShow;
}
