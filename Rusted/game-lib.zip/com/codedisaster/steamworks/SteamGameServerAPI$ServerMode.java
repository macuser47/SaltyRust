package com.codedisaster.steamworks;

public enum SteamGameServerAPI$ServerMode {
   Invalid,
   NoAuthentication,
   Authentication,
   AuthenticationAndSecure;
}
