package com.codedisaster.steamworks;

public enum SteamHTTP$API {
   Client,
   Server;
}
