package com.codedisaster.steamworks;

public enum SteamHTTP$HTTPMethod {
   Invalid,
   GET,
   HEAD,
   POST,
   PUT,
   DELETE,
   OPTIONS;
}
