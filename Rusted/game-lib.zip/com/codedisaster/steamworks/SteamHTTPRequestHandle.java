package com.codedisaster.steamworks;

public class SteamHTTPRequestHandle extends SteamNativeHandle {
   SteamHTTPRequestHandle(long var1) {
      super(var1);
   }
}
