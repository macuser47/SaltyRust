package com.codedisaster.steamworks;

public class SteamLeaderboardEntriesHandle extends SteamNativeHandle {
   SteamLeaderboardEntriesHandle(long var1) {
      super(var1);
   }
}
