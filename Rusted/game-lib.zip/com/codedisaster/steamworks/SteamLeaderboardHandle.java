package com.codedisaster.steamworks;

public class SteamLeaderboardHandle extends SteamNativeHandle {
   SteamLeaderboardHandle(long var1) {
      super(var1);
   }
}
