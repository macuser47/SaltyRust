package com.codedisaster.steamworks;

public enum SteamMatchmaking$LobbyDistanceFilter {
   Close,
   Default,
   Far,
   Worldwide;
}
