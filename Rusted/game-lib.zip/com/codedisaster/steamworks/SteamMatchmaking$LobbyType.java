package com.codedisaster.steamworks;

public enum SteamMatchmaking$LobbyType {
   Private,
   FriendsOnly,
   Public,
   Invisible;
}
