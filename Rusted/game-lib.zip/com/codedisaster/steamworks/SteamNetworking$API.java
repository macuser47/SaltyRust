package com.codedisaster.steamworks;

public enum SteamNetworking$API {
   Client,
   Server;
}
