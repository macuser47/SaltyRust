package com.codedisaster.steamworks;

public enum SteamNetworking$P2PSend {
   Unreliable,
   UnreliableNoDelay,
   Reliable,
   ReliableWithBuffering;
}
