package com.codedisaster.steamworks;

public class SteamPublishedFileUpdateHandle extends SteamNativeHandle {
   SteamPublishedFileUpdateHandle(long var1) {
      super(var1);
   }
}
