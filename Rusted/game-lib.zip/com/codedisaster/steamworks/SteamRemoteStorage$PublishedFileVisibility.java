package com.codedisaster.steamworks;

public enum SteamRemoteStorage$PublishedFileVisibility {
   Public,
   FriendsOnly,
   Private;
}
