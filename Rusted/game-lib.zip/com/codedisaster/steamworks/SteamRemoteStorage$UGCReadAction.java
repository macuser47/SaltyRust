package com.codedisaster.steamworks;

public enum SteamRemoteStorage$UGCReadAction {
   ContinueReadingUntilFinished,
   ContinueReading,
   Close;
}
