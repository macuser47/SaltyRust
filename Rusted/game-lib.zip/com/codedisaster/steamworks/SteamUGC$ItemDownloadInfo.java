package com.codedisaster.steamworks;

public class SteamUGC$ItemDownloadInfo {
   long bytesDownloaded;
   long bytesTotal;

   public long getBytesDownloaded() {
      return this.bytesDownloaded;
   }

   public long getBytesTotal() {
      return this.bytesTotal;
   }
}
