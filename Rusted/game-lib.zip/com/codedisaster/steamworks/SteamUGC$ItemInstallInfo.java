package com.codedisaster.steamworks;

public class SteamUGC$ItemInstallInfo {
   private String folder;
   private int sizeOnDisk;

   public String getFolder() {
      return this.folder;
   }

   public int getSizeOnDisk() {
      return this.sizeOnDisk;
   }
}
