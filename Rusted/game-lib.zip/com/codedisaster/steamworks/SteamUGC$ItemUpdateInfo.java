package com.codedisaster.steamworks;

public class SteamUGC$ItemUpdateInfo {
   long bytesProcessed;
   long bytesTotal;

   public long getBytesProcessed() {
      return this.bytesProcessed;
   }

   public long getBytesTotal() {
      return this.bytesTotal;
   }
}
