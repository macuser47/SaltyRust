package com.codedisaster.steamworks;

public enum SteamUGC$UserUGCListSortOrder {
   CreationOrderDesc,
   CreationOrderAsc,
   TitleAsc,
   LastUpdatedDesc,
   SubscriptionDateDesc,
   VoteScoreDesc,
   ForModeration;
}
