package com.codedisaster.steamworks;

public class SteamUGCFileWriteStreamHandle extends SteamNativeHandle {
   SteamUGCFileWriteStreamHandle(long var1) {
      super(var1);
   }
}
