package com.codedisaster.steamworks;

public class SteamUGCHandle extends SteamNativeHandle {
   public SteamUGCHandle(long var1) {
      super(var1);
   }
}
