package com.codedisaster.steamworks;

public enum SteamUserStats$LeaderboardDataRequest {
   Global,
   GlobalAroundUser,
   Friends,
   Users;
}
