package com.codedisaster.steamworks;

public enum SteamUserStats$LeaderboardDisplayType {
   None,
   Numeric,
   TimeSeconds,
   TimeMilliSeconds;
}
