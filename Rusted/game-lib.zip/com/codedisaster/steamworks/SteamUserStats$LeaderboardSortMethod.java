package com.codedisaster.steamworks;

public enum SteamUserStats$LeaderboardSortMethod {
   None,
   Ascending,
   Descending;
}
