package com.codedisaster.steamworks;

public enum SteamUserStats$LeaderboardUploadScoreMethod {
   None,
   KeepBest,
   ForceUpdate;
}
