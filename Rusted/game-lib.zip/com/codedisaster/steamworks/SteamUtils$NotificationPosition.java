package com.codedisaster.steamworks;

public enum SteamUtils$NotificationPosition {
   TopLeft,
   TopRight,
   BottomLeft,
   BottomRight;
}
