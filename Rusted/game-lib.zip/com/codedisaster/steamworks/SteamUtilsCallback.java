package com.codedisaster.steamworks;

public interface SteamUtilsCallback {
   void onSteamShutdown();
}
