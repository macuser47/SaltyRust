package com.corrodinggames.librocket;

// $FF: renamed from: com.corrodinggames.librocket.b
public class class_263 {
   // $FF: renamed from: a java.lang.String
   String field_2310;
   // $FF: renamed from: b java.lang.Runnable
   Runnable field_2311;

   public class_263(String var1, Runnable var2) {
      this.field_2310 = var1;
      this.field_2311 = var2;
   }
}
