package com.corrodinggames.librocket.scripts;

public class Multiplayer$DropdownOption {
   String key;
   String value;

   public Multiplayer$DropdownOption(String var1, String var2) {
      this.key = var1;
      this.value = var2;
   }
}
