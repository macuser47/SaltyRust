package com.corrodinggames.librocket.scripts;

public class Root$TableCell {
   public String text;
   public String classes;
   public String librocketOnClick;
   public Integer color;

   public void setLibrocketOnClick(String var1) {
      this.librocketOnClick = var1;
   }

   public Root$TableCell(String var1) {
      this.text = var1;
   }
}
