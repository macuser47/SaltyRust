package com.corrodinggames.librocket.scripts;

import com.corrodinggames.librocket.class_264;
import com.corrodinggames.rts.java.Main;
import java.util.HashMap;

public class ScriptContext {
   class_264 libRocket;
   Main main;
   ScriptEngine scriptEngine;
   HashMap methods = new HashMap();
}
