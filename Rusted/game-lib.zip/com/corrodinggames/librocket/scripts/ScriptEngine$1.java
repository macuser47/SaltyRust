package com.corrodinggames.librocket.scripts;

final class ScriptEngine$1 extends ThreadLocal {
   protected Boolean initialValue() {
      return false;
   }
}
