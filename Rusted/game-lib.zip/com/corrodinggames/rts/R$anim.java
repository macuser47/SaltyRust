package com.corrodinggames.rts;

public final class R$anim {
   public static int mainfadein = 2130968576;
   public static int splashfadeout = 2130968577;
}
