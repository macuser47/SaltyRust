package com.corrodinggames.rts;

public final class R$array {
   public static int aidifficulty_array = 2131099650;
   public static int credits_array = 2131099652;
   public static int fog_array = 2131099651;
   public static int keycode_labels = 2131099648;
   public static int onscreenlocation_array = 2131099649;
   public static int skirmish_ai_count = 2131099655;
   public static int skirmish_game_mode = 2131099654;
   public static int startingUnits_array = 2131099653;
}
