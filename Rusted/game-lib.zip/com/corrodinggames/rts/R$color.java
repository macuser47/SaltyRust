package com.corrodinggames.rts;

public final class R$color {
   public static int framecolour = 2131230721;
   public static int frametitlecolour = 2131230720;
}
