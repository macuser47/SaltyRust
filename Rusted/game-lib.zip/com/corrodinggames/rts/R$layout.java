package com.corrodinggames.rts;

public final class R$layout {
   public static int alert_chat = 2130903040;
   public static int credits = 2130903041;
   public static int intro_screen = 2130903042;
   public static int level_options_popup = 2130903043;
   public static int level_select = 2130903044;
   public static int level_select_grid = 2130903045;
   public static int load_level = 2130903046;
   public static int main = 2130903047;
   public static int menu = 2130903048;
   public static int mods = 2130903049;
   public static int multiplayer_battleroom = 2130903050;
   public static int multiplayer_battleroom_gameoptions = 2130903051;
   public static int multiplayer_battleroom_playerpopup = 2130903052;
   public static int multiplayer_lobby = 2130903053;
   public static int multiplayer_lobby_hostgame = 2130903054;
   public static int new_mission_starter = 2130903055;
   public static int quick_help = 2130903056;
   public static int replay_select = 2130903057;
   public static int settings = 2130903058;
   public static int settings_keyboard = 2130903059;
}
