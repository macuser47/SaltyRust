package com.corrodinggames.rts;

public final class R$raw {
   public static int attack = 2131034112;
   public static int bug_attack = 2131034113;
   public static int bug_die = 2131034114;
   public static int buiding_explode = 2131034115;
   public static int cannon_firing = 2131034116;
   public static int click = 2131034117;
   public static int firing3 = 2131034118;
   public static int firing4 = 2131034119;
   public static int gun_fire = 2131034120;
   public static int interface_error = 2131034121;
   public static int large_gun_fire1 = 2131034122;
   public static int large_gun_fire2 = 2131034123;
   public static int laser_deflect = 2131034124;
   public static int laser_deflect2 = 2131034125;
   public static int lighting_burst = 2131034126;
   public static int missile_fire = 2131034127;
   public static int missile_hit = 2131034128;
   public static int move = 2131034129;
   public static int nuke_explode = 2131034130;
   public static int nuke_launch = 2131034131;
   public static int plasma_fire = 2131034132;
   public static int plasma_fire2 = 2131034133;
   public static int tank_firing = 2131034134;
   public static int unit_explode = 2131034135;
   public static int unit_explode_old = 2131034136;
}
