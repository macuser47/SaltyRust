package com.corrodinggames.rts;

public final class R$string {
   public static int aidifficulty_prompt = 2131296258;
   public static int credits_prompt = 2131296260;
   public static int fog_prompt = 2131296259;
   public static int onscreenlocationaction_prompt = 2131296256;
   public static int onscreenlocationdpad_prompt = 2131296257;
   public static int skirmish_ai_count_prompt = 2131296263;
   public static int skirmish_game_mode_prompt = 2131296262;
   public static int startingUnits_prompt = 2131296261;
}
