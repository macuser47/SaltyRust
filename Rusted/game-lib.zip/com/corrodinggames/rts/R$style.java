package com.corrodinggames.rts;

public final class R$style {
   public static int CustomButton = 2131361797;
   public static int LevelButton = 2131361793;
   public static int MenuButton = 2131361792;
   public static int SettingsHeader = 2131361794;
   public static int SettingsMainButtons = 2131361796;
   public static int SettingsSectionGroup = 2131361795;
}
