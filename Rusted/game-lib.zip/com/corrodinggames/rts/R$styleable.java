package com.corrodinggames.rts;

public final class R$styleable {
   public static final int[] GalleryTheme = new int[]{16842828};
   public static final int GalleryTheme_android_galleryItemBackground = 0;
}
