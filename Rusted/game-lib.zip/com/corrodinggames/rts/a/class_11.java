package com.corrodinggames.rts.a;

import com.corrodinggames.rts.gameFramework.h.class_23;
import com.corrodinggames.rts.gameFramework.h.class_472;

// $FF: renamed from: com.corrodinggames.rts.a.d
public interface class_11 {
   // $FF: renamed from: a () void
   void method_24();

   // $FF: renamed from: b () boolean
   boolean method_25();

   // $FF: renamed from: c () boolean
   boolean method_26();

   // $FF: renamed from: d () com.corrodinggames.rts.gameFramework.h.a
   class_472 method_27();

   // $FF: renamed from: e () boolean
   boolean method_28();

   // $FF: renamed from: f () boolean
   boolean method_29();

   // $FF: renamed from: g () java.lang.Object
   Object method_30();

   // $FF: renamed from: h () int
   int method_31();

   // $FF: renamed from: i () int
   int method_32();

   // $FF: renamed from: j () void
   void method_33();

   // $FF: renamed from: k () com.corrodinggames.rts.a.e
   class_273 method_34();

   // $FF: renamed from: l () com.corrodinggames.rts.a.k
   class_352 method_35();

   // $FF: renamed from: a (float, int) void
   void method_36(float var1, int var2);

   // $FF: renamed from: b (float, int) void
   void method_37(float var1, int var2);

   // $FF: renamed from: m () void
   void method_38();

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.gameFramework.h.h
   class_23 method_39(boolean var1);

   // $FF: renamed from: a (com.corrodinggames.rts.gameFramework.h.h, boolean) void
   void method_40(class_23 var1, boolean var2);

   // $FF: renamed from: n () void
   void method_41();

   // $FF: renamed from: o () boolean
   boolean method_42();
}
