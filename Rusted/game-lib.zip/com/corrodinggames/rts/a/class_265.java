package com.corrodinggames.rts.a;

import android.app.Activity;

// $FF: renamed from: com.corrodinggames.rts.a.a
public class class_265 extends Activity {
}
