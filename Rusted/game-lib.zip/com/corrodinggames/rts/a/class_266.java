package com.corrodinggames.rts.a;

import android.app.Activity;

// $FF: renamed from: com.corrodinggames.rts.a.b
public class class_266 extends Activity {
}
