package com.corrodinggames.rts.a;

// $FF: renamed from: com.corrodinggames.rts.a.p
public class class_267 extends class_266 {
   // $FF: renamed from: b boolean
   boolean field_2329 = true;
}
