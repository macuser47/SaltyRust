package com.corrodinggames.rts.a;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class e$10 implements OnClickListener {
   // $FF: renamed from: a com.corrodinggames.rts.a.e
   // $FF: synthetic field
   final class_273 field_3245;

   e$10(class_273 var1) {
      this.field_3245 = var1;
   }

   public void onClick(DialogInterface var1, int var2) {
   }
}
