package com.corrodinggames.rts.a;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class e$11$1 implements OnClickListener {
   // $FF: renamed from: a java.lang.String
   // $FF: synthetic field
   final String field_3227;
   // $FF: renamed from: b com.corrodinggames.rts.a.e$11
   // $FF: synthetic field
   final e$11 field_3228;

   e$11$1(e$11 var1, String var2) {
      this.field_3228 = var1;
      this.field_3227 = var2;
   }

   public void onClick(DialogInterface var1, int var2) {
      class_273.method_1898(this.field_3228.field_3244, this.field_3227);
   }
}
