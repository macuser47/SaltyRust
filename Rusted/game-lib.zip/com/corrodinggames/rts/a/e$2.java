package com.corrodinggames.rts.a;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class e$2 implements OnClickListener {
   // $FF: renamed from: a com.corrodinggames.rts.a.e
   // $FF: synthetic field
   final class_273 field_2219;

   e$2(class_273 var1) {
      this.field_2219 = var1;
   }

   public void onClick(DialogInterface var1, int var2) {
   }
}
