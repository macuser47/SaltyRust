package com.corrodinggames.rts.a;

class e$3 implements Runnable {
   // $FF: renamed from: a com.corrodinggames.rts.a.e
   // $FF: synthetic field
   final class_273 field_2218;

   e$3(class_273 var1) {
      this.field_2218 = var1;
   }

   public void run() {
      class_273.method_1899(this.field_2218);
   }
}
