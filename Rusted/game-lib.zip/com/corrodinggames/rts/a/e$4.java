package com.corrodinggames.rts.a;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.corrodinggames.rts.gameFramework.class_236;

class e$4 implements OnClickListener {
   // $FF: renamed from: a com.corrodinggames.rts.a.e
   // $FF: synthetic field
   final class_273 field_2217;

   e$4(class_273 var1) {
      this.field_2217 = var1;
   }

   public void onClick(DialogInterface var1, int var2) {
      class_236.method_1549().field_2010 = true;
   }
}
