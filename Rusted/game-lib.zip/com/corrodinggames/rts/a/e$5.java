package com.corrodinggames.rts.a;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.corrodinggames.rts.gameFramework.class_236;
import com.corrodinggames.rts.gameFramework.class_289;

class e$5 implements OnClickListener {
   // $FF: renamed from: a com.corrodinggames.rts.a.e
   // $FF: synthetic field
   final class_273 field_2216;

   e$5(class_273 var1) {
      this.field_2216 = var1;
   }

   public void onClick(DialogInterface var1, int var2) {
      class_236 var3 = class_236.method_1549();
      var3.method_1577();
      var3.method_1570(true, class_289.field_2445);
      var3.method_1576();
   }
}
