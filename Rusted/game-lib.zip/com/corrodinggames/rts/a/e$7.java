package com.corrodinggames.rts.a;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class e$7 implements OnClickListener {
   // $FF: renamed from: a com.corrodinggames.rts.a.e
   // $FF: synthetic field
   final class_273 field_2214;

   e$7(class_273 var1) {
      this.field_2214 = var1;
   }

   public void onClick(DialogInterface var1, int var2) {
      this.field_2214.method_1871();
   }
}
