package com.corrodinggames.rts.a;

final class l$1 implements Runnable {
   // $FF: renamed from: a com.corrodinggames.rts.a.l
   // $FF: synthetic field
   final class_270 field_4716;
   // $FF: renamed from: b java.lang.String
   // $FF: synthetic field
   final String field_4717;

   l$1(class_270 var1, String var2) {
      this.field_4716 = var1;
      this.field_4717 = var2;
   }

   public void run() {
      this.field_4716.b();
      if (this.field_4717 != null) {
      }

   }
}
