package com.corrodinggames.rts.b.a;

// $FF: renamed from: com.corrodinggames.rts.b.a.c
public abstract class class_519 {
}
