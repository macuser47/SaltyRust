package com.corrodinggames.rts.b.a;

// $FF: renamed from: com.corrodinggames.rts.b.a.b
public class class_521 extends class_519 {
   // $FF: renamed from: a () void
   public void method_3294() {
   }
}
