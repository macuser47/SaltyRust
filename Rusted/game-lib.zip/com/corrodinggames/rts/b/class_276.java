package com.corrodinggames.rts.b;

// $FF: renamed from: com.corrodinggames.rts.b.c
public abstract class class_276 implements Runnable {
   // $FF: renamed from: c java.lang.Object
   Object field_2356;
}
