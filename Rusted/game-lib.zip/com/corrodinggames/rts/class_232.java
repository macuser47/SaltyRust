package com.corrodinggames.rts;

// $FF: renamed from: com.corrodinggames.rts.R
public final class class_232 {
}
