package com.corrodinggames.rts.game.a;

// $FF: renamed from: com.corrodinggames.rts.game.a.l
public class class_101 extends class_100 {
   public class_101(class_112 var1) {
      super(var1);
   }
}
