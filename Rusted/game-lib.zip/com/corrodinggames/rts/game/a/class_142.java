package com.corrodinggames.rts.game.a;

// $FF: renamed from: com.corrodinggames.rts.game.a.b
enum class_142 {
   // $FF: renamed from: a com.corrodinggames.rts.game.a.b
   field_1374,
   // $FF: renamed from: b com.corrodinggames.rts.game.a.b
   field_1375;
}
