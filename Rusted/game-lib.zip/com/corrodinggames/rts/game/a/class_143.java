package com.corrodinggames.rts.game.a;

// $FF: renamed from: com.corrodinggames.rts.game.a.i
enum class_143 {
   // $FF: renamed from: a com.corrodinggames.rts.game.a.i
   field_1377,
   // $FF: renamed from: b com.corrodinggames.rts.game.a.i
   field_1378,
   // $FF: renamed from: c com.corrodinggames.rts.game.a.i
   field_1379;

   // $FF: renamed from: a () int
   int method_1128() {
      return this.ordinal();
   }
}
