package com.corrodinggames.rts.game.a;

// $FF: renamed from: com.corrodinggames.rts.game.a.j
public enum class_147 {
   // $FF: renamed from: a com.corrodinggames.rts.game.a.j
   field_1387,
   // $FF: renamed from: b com.corrodinggames.rts.game.a.j
   field_1388,
   // $FF: renamed from: c com.corrodinggames.rts.game.a.j
   field_1389;
}
