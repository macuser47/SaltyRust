package com.corrodinggames.rts.game.a;

import com.corrodinggames.rts.game.units.class_24;

// $FF: renamed from: com.corrodinggames.rts.game.a.e
public class class_149 {
   // $FF: renamed from: a com.corrodinggames.rts.game.units.ap
   public class_24 field_1394;
   // $FF: renamed from: b float
   public float field_1395;
   // $FF: renamed from: c com.corrodinggames.rts.game.a.d
   // $FF: synthetic field
   final class_150 field_1396;

   public class_149(class_150 var1, class_24 var2, float var3) {
      this.field_1396 = var1;
      this.field_1394 = var2;
      this.field_1395 = var3;
   }
}
