package com.corrodinggames.rts.game.b;

import com.corrodinggames.rts.gameFramework.h.class_306;

// $FF: renamed from: com.corrodinggames.rts.game.b.j
class class_418 {
   // $FF: renamed from: a int
   static int field_3471 = 1;
   // $FF: renamed from: b boolean
   public boolean field_3472;
   // $FF: renamed from: c java.lang.String
   public String field_3473;
   // $FF: renamed from: d java.lang.String
   public String field_3474;
   // $FF: renamed from: e com.corrodinggames.rts.gameFramework.h.e
   public class_306 field_3475;
   // $FF: renamed from: f java.lang.String
   public String field_3476;
   // $FF: renamed from: g java.lang.String
   public String field_3477;
}
