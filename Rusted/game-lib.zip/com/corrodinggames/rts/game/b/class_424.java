package com.corrodinggames.rts.game.b;

// $FF: renamed from: com.corrodinggames.rts.game.b.f
public class class_424 extends RuntimeException {
   public class_424(String var1) {
      super(var1);
   }

   public class_424(String var1, Exception var2) {
      super(var1, var2);
   }
}
