package com.corrodinggames.rts.game;

// $FF: renamed from: com.corrodinggames.rts.game.m
public class class_108 extends class_107 {
   public class_108(int var1) {
   }

   // $FF: renamed from: a (float) void
   public void method_928(float var1) {
   }
}
