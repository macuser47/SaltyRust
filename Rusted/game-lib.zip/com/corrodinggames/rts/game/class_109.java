package com.corrodinggames.rts.game;

// $FF: renamed from: com.corrodinggames.rts.game.d
public class class_109 extends class_107 {
   public strictfp class_109(int var1) {
   }

   // $FF: renamed from: a (float) void
   public strictfp void method_928(float var1) {
   }
}
