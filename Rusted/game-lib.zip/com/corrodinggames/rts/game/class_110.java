package com.corrodinggames.rts.game;

// $FF: renamed from: com.corrodinggames.rts.game.e
public class class_110 extends class_107 {
   public strictfp class_110(int var1) {
      super(var1);
   }

   public strictfp class_110(int var1, boolean var2) {
      super(var1, var2);
   }

   // $FF: renamed from: a (float) void
   public strictfp void method_928(float var1) {
   }
}
