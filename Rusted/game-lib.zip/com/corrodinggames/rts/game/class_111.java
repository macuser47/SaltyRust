package com.corrodinggames.rts.game;

// $FF: renamed from: com.corrodinggames.rts.game.c
public class class_111 extends class_107 {
   public strictfp class_111(int var1) {
      super(var1);
   }

   // $FF: renamed from: a (float) void
   public strictfp void method_928(float var1) {
   }
}
