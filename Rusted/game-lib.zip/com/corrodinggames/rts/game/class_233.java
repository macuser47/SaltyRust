package com.corrodinggames.rts.game;

// $FF: renamed from: com.corrodinggames.rts.game.a
public abstract class class_233 {
   // $FF: renamed from: a int
   int field_1864 = 0;
   // $FF: renamed from: b boolean
   boolean field_1865 = false;
   // $FF: renamed from: c boolean
   boolean field_1866 = false;
   // $FF: renamed from: d boolean
   boolean field_1867 = false;
}
