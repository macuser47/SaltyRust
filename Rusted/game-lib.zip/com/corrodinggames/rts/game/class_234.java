package com.corrodinggames.rts.game;

// $FF: renamed from: com.corrodinggames.rts.game.b
public class class_234 extends class_233 {
}
