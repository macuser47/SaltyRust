package com.corrodinggames.rts.game;

// $FF: renamed from: com.corrodinggames.rts.game.j
public enum class_244 {
   // $FF: renamed from: a com.corrodinggames.rts.game.j
   field_2172,
   // $FF: renamed from: b com.corrodinggames.rts.game.j
   field_2173;
}
