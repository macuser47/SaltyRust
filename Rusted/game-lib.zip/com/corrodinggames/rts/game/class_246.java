package com.corrodinggames.rts.game;

// $FF: renamed from: com.corrodinggames.rts.game.l
public enum class_246 {
   // $FF: renamed from: a com.corrodinggames.rts.game.l
   field_2178,
   // $FF: renamed from: b com.corrodinggames.rts.game.l
   field_2179,
   // $FF: renamed from: c com.corrodinggames.rts.game.l
   field_2180;
}
