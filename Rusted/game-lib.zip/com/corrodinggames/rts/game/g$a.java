package com.corrodinggames.rts.game;

class g$a extends Thread {
   // $FF: renamed from: a com.corrodinggames.rts.game.g
   // $FF: synthetic field
   final class_237 field_4710;

   strictfp g$a(class_237 var1) {
      this.field_4710 = var1;
   }

   public strictfp void run() {
      this.field_4710.bp.method_2873("gotoNextLevel");
   }
}
