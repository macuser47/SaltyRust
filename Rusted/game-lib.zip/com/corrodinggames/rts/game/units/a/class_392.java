package com.corrodinggames.rts.game.units.a;

import com.corrodinggames.rts.game.units.class_39;

// $FF: renamed from: com.corrodinggames.rts.game.units.a.a
public class class_392 {
   // $FF: renamed from: a (com.corrodinggames.rts.game.units.a.l, com.corrodinggames.rts.game.units.aa) boolean
   public boolean method_2495(class_121 var1, class_39 var2) {
      return true;
   }
}
