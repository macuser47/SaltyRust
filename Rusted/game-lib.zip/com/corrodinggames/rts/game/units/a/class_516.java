package com.corrodinggames.rts.game.units.a;

// $FF: renamed from: com.corrodinggames.rts.game.units.a.n
public enum class_516 {
   // $FF: renamed from: a com.corrodinggames.rts.game.units.a.n
   field_4683,
   // $FF: renamed from: b com.corrodinggames.rts.game.units.a.n
   field_4684,
   // $FF: renamed from: c com.corrodinggames.rts.game.units.a.n
   field_4685,
   // $FF: renamed from: d com.corrodinggames.rts.game.units.a.n
   field_4686,
   // $FF: renamed from: e com.corrodinggames.rts.game.units.a.n
   field_4687,
   // $FF: renamed from: f com.corrodinggames.rts.game.units.a.n
   field_4688,
   // $FF: renamed from: g com.corrodinggames.rts.game.units.a.n
   field_4689,
   // $FF: renamed from: h com.corrodinggames.rts.game.units.a.n
   field_4690,
   // $FF: renamed from: i com.corrodinggames.rts.game.units.a.n
   field_4691,
   // $FF: renamed from: j com.corrodinggames.rts.game.units.a.n
   field_4692,
   // $FF: renamed from: k com.corrodinggames.rts.game.units.a.n
   field_4693,
   // $FF: renamed from: l com.corrodinggames.rts.game.units.a.n
   field_4694,
   // $FF: renamed from: m com.corrodinggames.rts.game.units.a.n
   field_4695;
}
