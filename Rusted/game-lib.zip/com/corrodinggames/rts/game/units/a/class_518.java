package com.corrodinggames.rts.game.units.a;

// $FF: renamed from: com.corrodinggames.rts.game.units.a.m
public enum class_518 {
   // $FF: renamed from: a com.corrodinggames.rts.game.units.a.m
   field_4700,
   // $FF: renamed from: b com.corrodinggames.rts.game.units.a.m
   field_4701,
   // $FF: renamed from: c com.corrodinggames.rts.game.units.a.m
   field_4702,
   // $FF: renamed from: d com.corrodinggames.rts.game.units.a.m
   field_4703,
   // $FF: renamed from: e com.corrodinggames.rts.game.units.a.m
   field_4704,
   // $FF: renamed from: f com.corrodinggames.rts.game.units.a.m
   field_4705,
   // $FF: renamed from: g com.corrodinggames.rts.game.units.a.m
   field_4706,
   // $FF: renamed from: h com.corrodinggames.rts.game.units.a.m
   field_4707;
}
