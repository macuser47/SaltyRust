package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.d.class_57;

enum ao$1 {
   // $FF: renamed from: j () boolean
   public boolean method_134() {
      return true;
   }

   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return true;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_57(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_57.method_560();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 700;
   }

   // $FF: renamed from: c (int) int
   public int method_3063(int var1) {
      if (var1 == 2) {
         return 1200;
      } else {
         return var1 == 3 ? 2500 : 0;
      }
   }

   // $FF: renamed from: n () boolean
   public boolean method_138() {
      return true;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 0.001F;
   }
}
