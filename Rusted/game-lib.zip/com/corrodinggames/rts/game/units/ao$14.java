package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.f.class_68;

enum ao$14 {
   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return false;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_68(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_68.method_612();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 1500;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 0.001F;
   }
}
