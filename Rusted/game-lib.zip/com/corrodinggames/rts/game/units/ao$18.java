package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.d.class_60;

enum ao$18 {
   // $FF: renamed from: j () boolean
   public boolean method_134() {
      return true;
   }

   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return true;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_60(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_60.method_566();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 1200;
   }

   // $FF: renamed from: c (int) int
   public int method_3063(int var1) {
      return var1 == 2 ? 2000 : 0;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 0.001F;
   }
}
