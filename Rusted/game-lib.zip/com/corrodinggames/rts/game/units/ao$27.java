package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.d.class_56;
import java.util.ArrayList;

enum ao$27 {
   // $FF: renamed from: j () boolean
   public boolean method_134() {
      return true;
   }

   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return false;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_56(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_56.method_555();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 11000;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 3.5E-4F;
   }

   // $FF: renamed from: a (java.util.ArrayList, int) void
   public void method_3051(ArrayList var1, int var2) {
      class_56.method_558(var1, var2);
   }
}
