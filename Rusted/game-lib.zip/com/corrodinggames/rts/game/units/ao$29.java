package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.d.class_64;

enum ao$29 {
   // $FF: renamed from: j () boolean
   public boolean method_134() {
      return true;
   }

   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return true;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_64(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_64.method_580();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 100;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 0.003F;
   }
}
