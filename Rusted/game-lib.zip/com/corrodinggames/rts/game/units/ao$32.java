package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.f.class_69;
import java.util.ArrayList;

enum ao$32 {
   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return true;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_69(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_69.method_614();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 500;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 0.001F;
   }

   // $FF: renamed from: k () boolean
   public boolean method_135() {
      return false;
   }

   // $FF: renamed from: a (java.util.ArrayList, int) void
   public void method_3051(ArrayList var1, int var2) {
      class_69.method_615(var1, var2);
   }
}
