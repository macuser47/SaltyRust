package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.d.class_62;
import java.util.ArrayList;

enum ao$34 {
   // $FF: renamed from: j () boolean
   public boolean method_134() {
      return true;
   }

   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return true;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_62(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_62.method_574();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 1000;
   }

   // $FF: renamed from: c (int) int
   public int method_3063(int var1) {
      return var1 == 2 ? 2000 : 0;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 7.0E-4F;
   }

   // $FF: renamed from: a (java.util.ArrayList, int) void
   public void method_3051(ArrayList var1, int var2) {
      class_62.method_576(var1, var2);
   }
}
