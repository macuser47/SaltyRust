package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.e.class_88;

enum ao$36 {
   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return false;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_88(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_88.method_667();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 21000;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 2.0E-4F;
   }

   // $FF: renamed from: g () int
   public int method_133() {
      return 3;
   }
}
