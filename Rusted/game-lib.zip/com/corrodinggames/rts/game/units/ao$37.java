package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.d.a.class_51;

enum ao$37 {
   // $FF: renamed from: j () boolean
   public boolean method_134() {
      return true;
   }

   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return true;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      class_51 var2 = new class_51(var1);
      var2.method_303("artillery");
      return var2;
   }

   // $FF: renamed from: b () void
   public void method_3050() {
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return class_469.field_4038.method_130() + class_51.field_402.method_1046();
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 6.0E-4F;
   }
}
