package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.b.class_78;

enum ao$4 {
   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return true;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_78(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_78.method_642();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 650;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 0.0012F;
   }
}
