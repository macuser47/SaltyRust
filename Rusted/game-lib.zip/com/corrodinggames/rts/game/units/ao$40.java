package com.corrodinggames.rts.game.units;

enum ao$40 {
   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return true;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      class_41 var2 = new class_41(var1);
      return var2;
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_41.method_332();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 1000;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 6.0E-4F;
   }
}
