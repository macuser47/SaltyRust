package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.d.class_55;
import java.util.ArrayList;

enum ao$45 {
   // $FF: renamed from: j () boolean
   public boolean method_134() {
      return true;
   }

   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return true;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_55(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_55.method_552();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 3000;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 5.0E-4F;
   }

   // $FF: renamed from: a (java.util.ArrayList, int) void
   public void method_3051(ArrayList var1, int var2) {
      class_55.method_554(var1, var2);
   }
}
