package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.e.class_84;
import java.util.ArrayList;

enum ao$48 {
   // $FF: renamed from: s () boolean
   public boolean method_126() {
      return true;
   }

   // $FF: renamed from: a (boolean) com.corrodinggames.rts.game.units.aa
   public class_39 method_3049(boolean var1) {
      return new class_84(var1);
   }

   // $FF: renamed from: b () void
   public void method_3050() {
      class_84.method_655();
   }

   // $FF: renamed from: c () int
   public int method_130() {
      return 500;
   }

   // $FF: renamed from: t () float
   public float method_132() {
      return 0.002F;
   }

   // $FF: renamed from: k () boolean
   public boolean method_135() {
      return true;
   }

   // $FF: renamed from: a (java.util.ArrayList, int) void
   public void method_3051(ArrayList var1, int var2) {
      class_84.method_658(var1, var2);
      class_81.method_649((ArrayList)null, var2);
   }
}
