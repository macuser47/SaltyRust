package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.y
public interface class_10 {
   // $FF: renamed from: j () int
   int method_20();

   // $FF: renamed from: l_ () boolean
   boolean method_21();

   // $FF: renamed from: m_ () boolean
   boolean method_22();

   // $FF: renamed from: n_ () boolean
   boolean method_23();
}
