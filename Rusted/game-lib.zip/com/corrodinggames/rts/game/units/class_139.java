package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.a.class_137;

// $FF: renamed from: com.corrodinggames.rts.game.units.h
class class_139 extends class_137 {
   public strictfp class_139() {
      super("addCredits");
   }

   // $FF: renamed from: b () java.lang.String
   public strictfp String method_1044() {
      return "Add credits";
   }

   // $FF: renamed from: a () java.lang.String
   public strictfp String method_1045() {
      return "Add $10000 to this team";
   }

   // $FF: renamed from: h () boolean
   public strictfp boolean method_1053() {
      return true;
   }
}
