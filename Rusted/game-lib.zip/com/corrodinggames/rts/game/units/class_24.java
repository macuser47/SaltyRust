package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.a.class_133;
import java.util.ArrayList;

// $FF: renamed from: com.corrodinggames.rts.game.units.ap
public interface class_24 {
   // $FF: renamed from: s () boolean
   boolean method_126();

   // $FF: renamed from: r () boolean
   boolean method_127();

   // $FF: renamed from: a () com.corrodinggames.rts.game.units.aa
   class_39 method_128();

   // $FF: renamed from: d () com.corrodinggames.rts.game.units.a.s
   class_133 method_129();

   // $FF: renamed from: c () int
   int method_130();

   // $FF: renamed from: b (int) int
   int method_131(int var1);

   // $FF: renamed from: t () float
   float method_132();

   // $FF: renamed from: g () int
   int method_133();

   // $FF: renamed from: j () boolean
   boolean method_134();

   // $FF: renamed from: k () boolean
   boolean method_135();

   // $FF: renamed from: l () boolean
   boolean method_136();

   // $FF: renamed from: m () com.corrodinggames.rts.game.units.ac
   class_503 method_137();

   // $FF: renamed from: n () boolean
   boolean method_138();

   // $FF: renamed from: e () java.lang.String
   String method_139();

   // $FF: renamed from: f () java.lang.String
   String method_140();

   // $FF: renamed from: i () java.lang.String
   String method_141();

   // $FF: renamed from: h () void
   void method_142();

   // $FF: renamed from: a (int) java.util.ArrayList
   ArrayList method_143(int var1);

   // $FF: renamed from: q () java.lang.String
   String method_144();
}
