package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.class_107;

// $FF: renamed from: com.corrodinggames.rts.game.units.am
public abstract class class_251 extends class_250 {
   // $FF: renamed from: a (com.corrodinggames.rts.game.units.p) int
   public abstract int method_1804(class_44 var1);

   // $FF: renamed from: b (com.corrodinggames.rts.game.units.p) com.corrodinggames.rts.game.k
   public abstract class_107 method_1805(class_44 var1);

   // $FF: renamed from: a (com.corrodinggames.rts.game.units.p, float) void
   public void method_1806(class_44 var1, float var2) {
   }
}
