package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.b
public enum class_280 {
   // $FF: renamed from: a com.corrodinggames.rts.game.units.b
   field_2401,
   // $FF: renamed from: b com.corrodinggames.rts.game.units.b
   field_2402,
   // $FF: renamed from: c com.corrodinggames.rts.game.units.b
   field_2403,
   // $FF: renamed from: d com.corrodinggames.rts.game.units.b
   field_2404;
}
