package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.a
public enum class_281 {
   // $FF: renamed from: a com.corrodinggames.rts.game.units.a
   field_2408,
   // $FF: renamed from: b com.corrodinggames.rts.game.units.a
   field_2409,
   // $FF: renamed from: c com.corrodinggames.rts.game.units.a
   field_2410,
   // $FF: renamed from: d com.corrodinggames.rts.game.units.a
   field_2411,
   // $FF: renamed from: e com.corrodinggames.rts.game.units.a
   field_2412,
   // $FF: renamed from: f com.corrodinggames.rts.game.units.a
   field_2413,
   // $FF: renamed from: g com.corrodinggames.rts.game.units.a
   field_2414;
}
