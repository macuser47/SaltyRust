package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.r
public enum class_282 {
   // $FF: renamed from: a com.corrodinggames.rts.game.units.r
   field_2421,
   // $FF: renamed from: b com.corrodinggames.rts.game.units.r
   field_2422,
   // $FF: renamed from: c com.corrodinggames.rts.game.units.r
   field_2423,
   // $FF: renamed from: d com.corrodinggames.rts.game.units.r
   field_2424,
   // $FF: renamed from: e com.corrodinggames.rts.game.units.r
   field_2425,
   // $FF: renamed from: f com.corrodinggames.rts.game.units.r
   field_2426;
}
