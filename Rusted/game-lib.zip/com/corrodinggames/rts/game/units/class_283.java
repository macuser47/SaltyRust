package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.gameFramework.f.class_404;
import com.corrodinggames.rts.gameFramework.f.class_463;

// $FF: renamed from: com.corrodinggames.rts.game.units.t
public class class_283 {
   // $FF: renamed from: a float
   public float field_2428;
   // $FF: renamed from: b float
   public float field_2429;

   // $FF: renamed from: a (com.corrodinggames.rts.gameFramework.f.af) void
   public strictfp void method_1980(class_404 var1) {
      var1.method_2542(this.field_2428);
      var1.method_2542(this.field_2429);
   }

   // $FF: renamed from: a (com.corrodinggames.rts.gameFramework.f.h) void
   public strictfp void method_1981(class_463 var1) {
      this.field_2428 = var1.method_3012();
      this.field_2429 = var1.method_3012();
   }
}
