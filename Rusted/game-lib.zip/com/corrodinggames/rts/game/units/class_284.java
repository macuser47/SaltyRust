package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.u
public enum class_284 {
   // $FF: renamed from: a com.corrodinggames.rts.game.units.u
   field_2430,
   // $FF: renamed from: b com.corrodinggames.rts.game.units.u
   field_2431,
   // $FF: renamed from: c com.corrodinggames.rts.game.units.u
   field_2432;
}
