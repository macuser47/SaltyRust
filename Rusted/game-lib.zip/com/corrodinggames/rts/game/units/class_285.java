package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.q
public class class_285 {
   // $FF: renamed from: a float
   public float field_2434;
   // $FF: renamed from: b float
   public float field_2435;
   // $FF: renamed from: c float
   public float field_2436;
   // $FF: renamed from: d int
   public int field_2437 = 1;

   // $FF: renamed from: a () float
   public strictfp float method_1982() {
      return (this.field_2435 + this.field_2436) / 60.0F;
   }
}
