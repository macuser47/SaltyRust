package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.m
public abstract class class_40 extends class_39 {
   public class_40(boolean var1) {
      super(var1);
   }
}
