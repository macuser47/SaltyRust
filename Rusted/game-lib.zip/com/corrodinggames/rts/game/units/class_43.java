package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.c
public abstract class class_43 extends class_39 {
   protected strictfp class_43(boolean var1) {
      super(var1);
   }
}
