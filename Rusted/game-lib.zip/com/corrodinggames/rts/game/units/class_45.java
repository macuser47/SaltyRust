package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.class_97;
import com.corrodinggames.rts.game.units.e.class_84;
import com.corrodinggames.rts.gameFramework.h.class_306;

// $FF: renamed from: com.corrodinggames.rts.game.units.o
public abstract class class_45 extends class_44 {
   // $FF: renamed from: p () com.corrodinggames.rts.gameFramework.h.e
   public strictfp class_306 method_240() {
      return null;
   }

   // $FF: renamed from: d () com.corrodinggames.rts.gameFramework.h.e
   public strictfp class_306 method_346() {
      return class_84.field_733;
   }

   // $FF: renamed from: k () com.corrodinggames.rts.gameFramework.h.e
   public strictfp class_306 method_347() {
      return null;
   }

   // $FF: renamed from: d (int) com.corrodinggames.rts.gameFramework.h.e
   public strictfp class_306 method_348(int var1) {
      return null;
   }

   // $FF: renamed from: e () boolean
   public strictfp boolean method_250() {
      return false;
   }

   public strictfp class_45(boolean var1) {
      super(var1);
      this.J(20);
      this.K(20);
      this.by = 1.0F;
      this.bz = this.by;
      this.bh = false;
      this.bJ = 100.0F;
      this.bI = this.bJ;
      this.G = class_84.field_733;
   }

   // $FF: renamed from: a (float) void
   public strictfp void method_176(float var1) {
      super.method_176(var1);
   }

   // $FF: renamed from: a (float, boolean) void
   public strictfp void method_177(float var1, boolean var2) {
   }

   // $FF: renamed from: e (int) float
   public strictfp float method_445(int var1) {
      return 0.0F;
   }

   // $FF: renamed from: f (int) float
   public strictfp float method_448(int var1) {
      return 0.0F;
   }

   // $FF: renamed from: c (float) boolean
   public strictfp boolean method_181(float var1) {
      return false;
   }

   // $FF: renamed from: a (com.corrodinggames.rts.game.units.aa, int) void
   public strictfp void method_471(class_39 var1, int var2) {
   }

   // $FF: renamed from: m () float
   public strictfp float method_439() {
      return 30.0F;
   }

   // $FF: renamed from: b (int) float
   public strictfp float method_441(int var1) {
      return 100.0F;
   }

   // $FF: renamed from: s () float
   public strictfp float method_458() {
      return 0.0F;
   }

   // $FF: renamed from: t () float
   public strictfp float method_451() {
      return 4.8F;
   }

   // $FF: renamed from: u () float
   public strictfp float method_452() {
      return 0.35F;
   }

   // $FF: renamed from: c (int) float
   public strictfp float method_453(int var1) {
      return 99.0F;
   }

   // $FF: renamed from: l () boolean
   public strictfp boolean method_312() {
      return false;
   }

   // $FF: renamed from: v () float
   public strictfp float method_466() {
      return 0.04F;
   }

   // $FF: renamed from: w () float
   public strictfp float method_467() {
      return 0.1F;
   }

   // $FF: renamed from: x () boolean
   public strictfp boolean method_456() {
      return true;
   }

   // $FF: renamed from: g (int) float
   public strictfp float method_474(int var1) {
      return 10.0F;
   }

   // $FF: renamed from: y () boolean
   public strictfp boolean method_426() {
      return false;
   }

   // $FF: renamed from: z () float
   public strictfp float method_428() {
      return 1.0F;
   }

   // $FF: renamed from: A () float
   public strictfp float method_429() {
      return 1.0F;
   }

   // $FF: renamed from: B () boolean
   public strictfp boolean method_318() {
      return true;
   }

   // $FF: renamed from: d (com.corrodinggames.rts.game.units.aa) boolean
   public strictfp boolean method_319(class_39 var1) {
      return false;
   }

   // $FF: renamed from: C () boolean
   public strictfp boolean method_431() {
      return false;
   }

   // $FF: renamed from: a (com.corrodinggames.rts.game.units.aa, float, com.corrodinggames.rts.game.f) float
   public strictfp float method_246(class_39 var1, float var2, class_97 var3) {
      var2 = 0.0F;
      return super.a(var1, var2, var3);
   }

   // $FF: renamed from: G () boolean
   public strictfp boolean method_286() {
      return true;
   }

   // $FF: renamed from: H () boolean
   public strictfp boolean method_282() {
      return false;
   }

   // $FF: renamed from: i () boolean
   public strictfp boolean method_280() {
      return true;
   }

   // $FF: renamed from: h () com.corrodinggames.rts.game.units.ac
   public strictfp class_503 method_279() {
      return class_503.field_4620;
   }
}
