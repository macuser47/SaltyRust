package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.as
public enum class_501 {
   // $FF: renamed from: a com.corrodinggames.rts.game.units.as
   field_4595,
   // $FF: renamed from: b com.corrodinggames.rts.game.units.as
   field_4596,
   // $FF: renamed from: c com.corrodinggames.rts.game.units.as
   field_4597,
   // $FF: renamed from: d com.corrodinggames.rts.game.units.as
   field_4598,
   // $FF: renamed from: e com.corrodinggames.rts.game.units.as
   field_4599,
   // $FF: renamed from: f com.corrodinggames.rts.game.units.as
   field_4600,
   // $FF: renamed from: g com.corrodinggames.rts.game.units.as
   field_4601,
   // $FF: renamed from: h com.corrodinggames.rts.game.units.as
   field_4602,
   // $FF: renamed from: i com.corrodinggames.rts.game.units.as
   field_4603,
   // $FF: renamed from: j com.corrodinggames.rts.game.units.as
   field_4604,
   // $FF: renamed from: k com.corrodinggames.rts.game.units.as
   field_4605,
   // $FF: renamed from: l com.corrodinggames.rts.game.units.as
   field_4606;
}
