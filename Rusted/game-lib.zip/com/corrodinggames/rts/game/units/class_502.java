package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.ad
public class class_502 {
   // $FF: renamed from: a float
   public float field_4608;
   // $FF: renamed from: b float
   public float field_4609;
   // $FF: renamed from: c float
   public float field_4610;
   // $FF: renamed from: d float
   public float field_4611;
   // $FF: renamed from: e float
   public float field_4612;
   // $FF: renamed from: f boolean
   public boolean field_4613;
   // $FF: renamed from: g float
   public float field_4614;
   // $FF: renamed from: h float
   public float field_4615;
   // $FF: renamed from: i com.corrodinggames.rts.game.units.aa
   public class_39 field_4616;
}
