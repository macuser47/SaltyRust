package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.gameFramework.utility.class_201;

// $FF: renamed from: com.corrodinggames.rts.game.units.ah
public class class_506 {
   // $FF: renamed from: a com.corrodinggames.rts.gameFramework.utility.s
   public class_201 field_4646 = new class_201();
}
