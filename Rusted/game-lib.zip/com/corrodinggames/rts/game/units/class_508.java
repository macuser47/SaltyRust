package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.aj
public abstract class class_508 {
   // $FF: renamed from: a (com.corrodinggames.rts.game.units.aa) boolean
   public abstract boolean method_3248(class_39 var1);
}
