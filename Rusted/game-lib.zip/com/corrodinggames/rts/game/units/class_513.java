package com.corrodinggames.rts.game.units;

import java.util.ArrayList;

// $FF: renamed from: com.corrodinggames.rts.game.units.aq
public class class_513 {
   // $FF: renamed from: a java.util.ArrayList
   public ArrayList field_4679 = new ArrayList();
}
