package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.gameFramework.b.class_388;

// $FF: renamed from: com.corrodinggames.rts.game.units.ab
public class class_517 {
   // $FF: renamed from: a boolean
   boolean field_4697 = false;
   // $FF: renamed from: b int
   int field_4698;
   // $FF: renamed from: c com.corrodinggames.rts.gameFramework.b.a
   class_388 field_4699;
}
