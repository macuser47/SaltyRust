package com.corrodinggames.rts.game.units;

// $FF: renamed from: com.corrodinggames.rts.game.units.n
public abstract class class_65 extends class_44 {
   public strictfp class_65(boolean var1) {
      super(var1);
   }

   // $FF: renamed from: C () boolean
   public strictfp boolean method_431() {
      return true;
   }

   // $FF: renamed from: i () boolean
   public strictfp boolean method_280() {
      return false;
   }

   // $FF: renamed from: H () boolean
   public strictfp boolean method_282() {
      return false;
   }
}
