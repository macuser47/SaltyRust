package com.corrodinggames.rts.game.units;

import android.graphics.PointF;

// $FF: renamed from: com.corrodinggames.rts.game.units.d
public interface class_9 {
   // $FF: renamed from: b () android.graphics.PointF[]
   PointF[] method_18();

   // $FF: renamed from: c () android.graphics.PointF[]
   PointF[] method_19();
}
