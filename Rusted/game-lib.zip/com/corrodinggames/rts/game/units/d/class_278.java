package com.corrodinggames.rts.game.units.d;

import com.corrodinggames.rts.game.units.class_44;

// $FF: renamed from: com.corrodinggames.rts.game.units.d.m
public class class_278 extends class_277 {
   public strictfp class_278(class_44 var1) {
      super(var1);
   }
}
