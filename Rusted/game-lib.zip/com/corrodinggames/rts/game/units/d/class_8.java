package com.corrodinggames.rts.game.units.d;

import android.graphics.PointF;
import com.corrodinggames.rts.game.units.class_24;

// $FF: renamed from: com.corrodinggames.rts.game.units.d.k
public interface class_8 {
   // $FF: renamed from: cl () boolean
   boolean method_9();

   // $FF: renamed from: a (com.corrodinggames.rts.game.units.d.i) void
   void method_10(class_32 var1);

   // $FF: renamed from: h (com.corrodinggames.rts.game.units.ap) int
   int method_11(class_24 var1);

   // $FF: renamed from: e (boolean) int
   int method_12(boolean var1);

   // $FF: renamed from: a (java.lang.String, boolean) int
   int method_13(String var1, boolean var2);

   // $FF: renamed from: cj () boolean
   boolean method_14();

   // $FF: renamed from: a (android.graphics.PointF) void
   void method_15(PointF var1);

   // $FF: renamed from: ck () void
   void method_16();

   // $FF: renamed from: ci () com.corrodinggames.rts.game.units.d.i
   class_32 method_17();
}
