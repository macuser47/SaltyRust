package com.corrodinggames.rts.game.units;

import com.corrodinggames.rts.game.units.a.class_121;
import com.corrodinggames.rts.game.units.a.class_392;

final class g$3 extends class_392 {
   // $FF: renamed from: a (com.corrodinggames.rts.game.units.a.l, com.corrodinggames.rts.game.units.aa) boolean
   public boolean method_2495(class_121 var1, class_39 var2) {
      class_24 var3 = var1.method_1055();
      return class_81.method_648().field_717.method_1956(var3);
   }
}
