package com.corrodinggames.rts.game.units;

enum k$1 {
   // $FF: renamed from: a (com.corrodinggames.rts.game.units.ap) boolean
   public boolean method_1956(class_24 var1) {
      return true;
   }
}
