package com.corrodinggames.rts.game.units;

enum k$5 {
   // $FF: renamed from: a (com.corrodinggames.rts.game.units.ap) boolean
   public boolean method_1956(class_24 var1) {
      if (var1 == null) {
         return false;
      } else {
         class_39 var2 = class_39.method_217(var1);
         return !var2.method_222() && var1.method_134();
      }
   }
}
