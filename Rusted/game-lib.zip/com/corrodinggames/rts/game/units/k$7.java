package com.corrodinggames.rts.game.units;

enum k$7 {
   // $FF: renamed from: a (com.corrodinggames.rts.game.units.ap) boolean
   public boolean method_1956(class_24 var1) {
      return var1 == null;
   }
}
