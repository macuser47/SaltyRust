package com.corrodinggames.rts.game.units;

final class p$1 extends class_250 {
   // $FF: renamed from: a (com.corrodinggames.rts.game.units.p, float, com.corrodinggames.rts.game.units.aa) void
   public void method_1803(class_44 var1, float var2, class_39 var3) {
      class_44.method_503(var1, var3, var2, true);
   }
}
